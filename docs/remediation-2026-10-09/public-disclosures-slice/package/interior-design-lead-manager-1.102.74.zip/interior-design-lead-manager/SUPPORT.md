# Support, security reports and managed updates

Author / Builder: Shashi. Updated: 2026-10-09. Applies to candidate 1.102.74.

## Contact

For plugin support, reviewed update requests and private security reports, contact Shashi at **[mlshashikiran@gmail.com](mailto:mlshashikiran@gmail.com)**. This address is the owner-supplied contact for all three purposes. For customer data/access requests, contact the administrator of the WordPress site that holds the records; the plugin author does not automatically receive or control that site's CRM data.

For support, include the plugin, PHP and WordPress versions, the affected workflow, expected/actual behavior and synthetic reproduction steps. Share redacted diagnostics only. Do not email live customer exports, passwords, access tokens, API secrets, encryption keys, salts or a full database backup. If further private evidence is needed, agree on a secure transfer method first. No response-time or availability guarantee is published.

Report suspected vulnerabilities privately to the same address with a concise description, affected version and synthetic reproduction. Avoid posting customer data, secrets or exploitable details in public issues. Email sent to this address is handled by the recipient's mail service; contacting support is a user-initiated transfer, not automatic plugin telemetry.

## Distribution and updates

The current process is a manually supplied, reviewed ZIP. The plugin contains no custom automatic update service, license activation server or guaranteed WordPress.org update listing. A development checkout, internal Git URL, local rehearsal ZIP or an artifact marked unapproved is not a production release channel. Request an approved ZIP, version, checksum and migration/recovery notes through the support contact.

Before replacing the plugin:

1. Take and verify a full WordPress database backup, filesystem/media backup and secure copy of the encryption key or matching WordPress salts. The plugin's JSON export is only a partial CRM backup; see [Privacy and data lifecycle](PRIVACY.md).
2. Verify the supplied version/checksum and rehearse that exact ZIP on a staging copy. Check schema status, sign-in/access, lead/task/quotation flows, private downloads, scheduler state and required integrations using synthetic data.
3. Record the provider/rule and queue state; pause configured outbound work for maintenance. Existing provider requests already in flight cannot be recalled. Restore the intended settings deliberately after successful verification.
4. Deploy only the approved artifact through the site's controlled WordPress/plugin update process. Retain the original backup and release identity for recovery.

No rollback is guaranteed by installing an older ZIP. A schema or data change may require restoring the matching database, private files, media and encryption material together. Recovery may reintroduce erased records or provider work, so reconcile it before reopening integrations. Full-database loss can also remove delivery receipts and permit a later replay; the plugin does not guarantee exactly-once provider delivery.

## Current qualification boundary

The audit remediation candidate is local and unapproved for production. Public/runtime metadata is being reviewed separately under REL-005; do not infer a tested support floor or matrix from metadata alone. Multisite/network activation, distributed database/cache topologies, all scheduler variants, provider sandboxes and full installed-artifact recovery remain subject to qualification. This document does not claim directory approval, legal compliance, or a production release.
