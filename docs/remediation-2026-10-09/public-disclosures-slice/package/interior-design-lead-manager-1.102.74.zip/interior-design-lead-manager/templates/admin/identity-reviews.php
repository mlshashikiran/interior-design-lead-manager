<?php
/** Manager-only held submission decisions. Builder: Shashi. */
if (!defined('ABSPATH')) { exit; }
$rows = $context['rows'];
$status = $context['status'];
?>
<div class="wrap idlm-identity-reviews">
    <h1>Identity reviews</h1>
    <?php if (isset($_GET['resolved']) && '1' === $_GET['resolved']) : ?><div class="notice notice-success" role="status"><p>Review resolved.</p></div><?php endif; ?>
    <p>Choose a canonical candidate, create a separate unassigned lead, or reject the submission. Every decision requires a reason. Reviews expire under the touchpoint retention policy.</p>
    <p><?php foreach (array('pending','matched','separate','rejected') as $filter) : ?><a class="button" href="<?php echo esc_url(add_query_arg('status', $filter, admin_url('admin.php?page=idlm_identity_reviews'))); ?>"><?php echo esc_html(ucfirst($filter)); ?></a> <?php endforeach; ?></p>
    <?php if (!$rows) : ?><p>No reviews in this status.</p><?php endif; ?>
    <?php foreach ($rows as $review) : ?>
        <section class="card" style="max-width:800px;overflow-wrap:anywhere">
            <h2><?php echo esc_html('Submission #' . $review->id); ?></h2>
            <p><?php echo esc_html($review->source . ' · ' . $review->email . ' · ' . $review->phone . ' · ' . $review->received_at); ?></p>
            <dl><?php foreach (IDLM_Identity_Review::data($review) as $field => $value) : ?>
                <?php if (in_array($field, array('first_name', 'last_name', 'project_name', 'property_location', 'budget', 'project_timeline'), true) && $value !== '') : ?>
                    <dt><?php echo esc_html(ucwords(str_replace('_', ' ', $field))); ?></dt><dd><?php echo esc_html($value); ?></dd>
                <?php endif; ?>
            <?php endforeach; ?></dl>
            <?php if ($review->status !== 'pending') : ?>
                <p><?php echo esc_html(sprintf('%s · lead #%d · decided by user #%d · %s', $review->status, $review->resolved_lead_id, $review->resolved_by, $review->resolved_at)); ?></p>
                <p><?php echo esc_html($review->resolution_note); ?></p>
            <?php else : ?>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="idlm_resolve_identity_review">
                <input type="hidden" name="review_id" value="<?php echo esc_attr($review->id); ?>">
                <?php wp_nonce_field(IDLM_Identity_Review::nonce_action($review->id)); ?>
                <p><label for="decision-<?php echo esc_attr($review->id); ?>">Decision</label>
                    <select style="max-width:100%" required name="decision" id="decision-<?php echo esc_attr($review->id); ?>"><option value="matched">Use canonical candidate</option><option value="separate">Create separate unassigned lead</option><option value="rejected">Reject submission</option></select></p>
                <p><label for="candidate-<?php echo esc_attr($review->id); ?>">Canonical candidate (for use canonical candidate)</label>
                    <select style="max-width:100%" name="lead_id" id="candidate-<?php echo esc_attr($review->id); ?>"><option value="0">Select candidate</option>
                    <?php foreach (IDLM_Identity_Review::candidate_ids($review) as $id) : $lead = IDLM_Identity_Review::candidate_lead($id); ?>
                        <?php if ($lead && empty($lead->is_duplicate)) : ?><option value="<?php echo esc_attr($id); ?>"><?php echo esc_html('#' . $id . ' · ' . $lead->first_name . ' ' . $lead->last_name . ' · ' . $lead->email . ' · ' . $lead->phone); ?></option><?php endif; ?>
                    <?php endforeach; ?></select></p>
                <p><label for="note-<?php echo esc_attr($review->id); ?>">Reason</label><br><textarea required maxlength="1000" rows="3" style="width:100%;box-sizing:border-box" name="note" id="note-<?php echo esc_attr($review->id); ?>"></textarea></p>
                <button class="button button-primary" type="submit">Resolve submission</button>
            </form>
            <?php endif; ?>
        </section>
    <?php endforeach; ?>
    <p><a class="button" href="<?php echo esc_url(add_query_arg('status', $status, admin_url('admin.php?page=idlm_identity_reviews'))); ?>">First page</a>
    <?php if (count($rows) === 25) : $last = end($rows); ?><a class="button" href="<?php echo esc_url(add_query_arg(array('after' => $last->id, 'status' => $status), admin_url('admin.php?page=idlm_identity_reviews'))); ?>">Next page</a><?php endif; ?></p>
</div>
